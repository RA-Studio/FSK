<?php include ("header.php");?>


    <title>Коммерческие помещения в UP Кварталах</title>

</head>
<body>


<?php include ("navbar_with_menu.php");?>


<?php include ("section_zhk_list.php");?>


<?php include ("section_photogalereya.php");?>


<?php include ("section_f_list.php");?>


<?php include ("section_o_zastrojshike.php");?>


<?php include ("section_discount_and_disclaimer.php");?>


<?php include ("footer.php");?>